代码文件为：

PyTorch版本前馈神经网络train_pytorch.py；
sklearn版本前馈神经网络train.py；
绘图代码matplot.py。


loss_data文件夹下为历次测试的输出列表。