./Results 文件夹中为各个测试数据结果，其中以acc开头的是准确率测试结果，以loss开头的是损失值测试结果。

训练代码文件见./train_cuda.py
绘图代码./matplot.py